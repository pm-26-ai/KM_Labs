import React from 'react';
import { BarChart3, ArrowUp, Shield, Award, TrendingUp, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const currentYear = new Date().getFullYear();

  const footerLinks = {
    'Services': ['Strategy Backtesting', 'Trading Bot Creation', 'Market Scanners', 'Consultancy', 'Training', 'Custom Indicators'],
    'Solutions': ['Algorithmic Trading', 'Data Science', 'HRMS Solutions', 'Hospitality Solutions'],
    'Resources': ['Documentation', 'API Reference', 'Tutorials', 'Case Studies'],
    'Company': ['About Us', 'Our Team', 'Careers', 'Contact Us']
  };

  const certifications = [
    { name: 'ISO Certified', icon: Shield },
    { name: 'Industry Expert', icon: Award },
    { name: 'Proven Track Record', icon: TrendingUp }
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-6 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-emerald-400 to-blue-400 rounded-lg flex items-center justify-center">
                <BarChart3 className="h-5 w-5 text-white" />
              </div>
              <h3 className="text-2xl font-bold bg-gradient-to-r from-emerald-400 to-blue-400 bg-clip-text text-transparent">
                Kimbly Labs
              </h3>
            </div>
            <p className="text-gray-300 mb-6 max-w-md">
              Advanced algorithmic trading solutions for modern traders. Technology-driven company 
              specializing in Algorithmic Trading, Data Science, HRMS, and Hospitality Solutions.
            </p>
            
            {/* Contact Info */}
            <div className="space-y-3 mb-6">
              <div className="flex items-center space-x-2 text-sm text-gray-400">
                <Mail className="h-4 w-4 text-emerald-400" />
                <span>kimblylabs@gmail.com</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-400">
                <Phone className="h-4 w-4 text-emerald-400" />
                <span>+91 9873098686</span>
              </div>
              <div className="flex items-start space-x-2 text-sm text-gray-400">
                <MapPin className="h-4 w-4 text-emerald-400 mt-0.5" />
                <span>Workify Office, 264, Udyog Vihar Phase - 1, Gurugram</span>
              </div>
            </div>
            
            {/* Certifications */}
            <div className="space-y-3">
              <h4 className="font-semibold text-white text-sm">Our Credentials</h4>
              {certifications.map((cert, index) => {
                const Icon = cert.icon;
                return (
                  <div key={index} className="flex items-center space-x-2 text-sm text-gray-400">
                    <Icon className="h-4 w-4 text-emerald-400" />
                    <span>{cert.name}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Links Sections */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h4 className="font-semibold text-white mb-4">{category}</h4>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link}>
                    <a 
                      href="#"
                      className="text-gray-400 hover:text-emerald-400 transition-colors duration-200 text-sm"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Mission Statement */}
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="bg-gray-800 rounded-lg p-6 mb-8">
            <h4 className="font-semibold text-white mb-3 flex items-center">
              <TrendingUp className="h-5 w-5 mr-2 text-emerald-400" />
              Our Mission
            </h4>
            <p className="text-gray-300 text-sm leading-relaxed">
              We are on a mission to democratize algorithmic trading, making professional-grade tools 
              accessible to traders of all levels—whether you're a day trader, swing trader, or long-term investor. 
              With a strong focus on performance, reliability, and user experience, Kimbly Labs is your trusted 
              partner in navigating today's fast-paced financial markets.
            </p>
          </div>
          
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 text-gray-400 mb-4 md:mb-0">
              <span>© {currentYear} Kimbly Labs. All rights reserved.</span>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-xs text-gray-500">
                Made with ❤️ in India
              </div>
              <button 
                onClick={scrollToTop}
                className="bg-emerald-600 hover:bg-emerald-700 text-white p-3 rounded-lg transition-colors duration-200"
                aria-label="Scroll to top"
              >
                <ArrowUp className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;