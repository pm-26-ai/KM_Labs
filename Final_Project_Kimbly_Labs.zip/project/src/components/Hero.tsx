import React, { useEffect, useState } from 'react';
import { ChevronDown, TrendingUp, DollarSign, Target, BarChart3, Activity, Zap, ArrowRight } from 'lucide-react';

const Hero = () => {
  const [marketData, setMarketData] = useState({
    sp500: 4850.25,
    nasdaq: 15420.30,
    dow: 38250.75,
    vix: 18.45
  });

  const [liveStats, setLiveStats] = useState({
    totalClients: 0,
    successRate: 0,
    activeStrategies: 0,
    yearsExperience: 0
  });

  useEffect(() => {
    const marketInterval = setInterval(() => {
      setMarketData(prev => ({
        sp500: prev.sp500 + (Math.random() - 0.5) * 10,
        nasdaq: prev.nasdaq + (Math.random() - 0.5) * 50,
        dow: prev.dow + (Math.random() - 0.5) * 30,
        vix: Math.max(10, prev.vix + (Math.random() - 0.5) * 2)
      }));
    }, 2000);

    const animateCounter = (target: number, key: string) => {
      let current = 0;
      const increment = target / 100;
      const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
          current = target;
          clearInterval(timer);
        }
        setLiveStats(prev => ({ ...prev, [key]: Math.floor(current) }));
      }, 30);
    };

    animateCounter(500, 'totalClients');
    animateCounter(95, 'successRate');
    animateCounter(50, 'activeStrategies');
    animateCounter(10, 'yearsExperience');

    return () => clearInterval(marketInterval);
  }, []);

  const scrollToAbout = () => {
    const element = document.getElementById('about');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToServices = () => {
    const element = document.getElementById('services');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden bg-white">
      {/* Clean Background Pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-50 via-white to-blue-50/30">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(14,165,233,0.05),transparent_50%)]"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(16,185,129,0.05),transparent_50%)]"></div>
      </div>

      {/* Live Market Ticker */}
      <div className="absolute top-16 left-0 right-0 bg-slate-900 text-white py-3 overflow-hidden border-b border-slate-800">
        <div className="flex animate-scroll whitespace-nowrap">
          <div className="flex space-x-12 text-sm font-medium">
            <span className="flex items-center space-x-2">
              <span className="text-slate-400">S&P 500:</span>
              <span className={marketData.sp500 > 4850 ? 'text-emerald-400' : 'text-red-400'}>
                ${marketData.sp500.toFixed(2)}
              </span>
              <span className={`text-xs ${marketData.sp500 > 4850 ? 'text-emerald-400' : 'text-red-400'}`}>
                {marketData.sp500 > 4850 ? '↗' : '↘'}
              </span>
            </span>
            <span className="flex items-center space-x-2">
              <span className="text-slate-400">NASDAQ:</span>
              <span className={marketData.nasdaq > 15420 ? 'text-emerald-400' : 'text-red-400'}>
                ${marketData.nasdaq.toFixed(2)}
              </span>
              <span className={`text-xs ${marketData.nasdaq > 15420 ? 'text-emerald-400' : 'text-red-400'}`}>
                {marketData.nasdaq > 15420 ? '↗' : '↘'}
              </span>
            </span>
            <span className="flex items-center space-x-2">
              <span className="text-slate-400">DOW:</span>
              <span className={marketData.dow > 38250 ? 'text-emerald-400' : 'text-red-400'}>
                ${marketData.dow.toFixed(2)}
              </span>
              <span className={`text-xs ${marketData.dow > 38250 ? 'text-emerald-400' : 'text-red-400'}`}>
                {marketData.dow > 38250 ? '↗' : '↘'}
              </span>
            </span>
            <span className="flex items-center space-x-2">
              <span className="text-slate-400">VIX:</span>
              <span className={marketData.vix < 20 ? 'text-emerald-400' : 'text-red-400'}>
                {marketData.vix.toFixed(2)}
              </span>
              <span className={`text-xs ${marketData.vix < 20 ? 'text-emerald-400' : 'text-red-400'}`}>
                {marketData.vix < 20 ? '↘' : '↗'}
              </span>
            </span>
          </div>
        </div>
      </div>

      <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto mt-20">
        {/* Status Badge */}
        <div className="flex justify-center mb-8">
          <div className="flex items-center space-x-3 px-6 py-3 bg-white/80 backdrop-blur-sm rounded-full border border-slate-200/50 shadow-lg">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
            <span className="text-slate-700 text-sm font-medium">Live Trading Solutions</span>
            <Activity className="h-4 w-4 text-emerald-600" />
          </div>
        </div>

        {/* Main Headline - Fixed text visibility with proper line height and padding */}
        <div className="mb-8">
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold leading-[1.1] pb-4">
            <span className="block bg-gradient-to-r from-teal-600 via-blue-600 to-indigo-600 bg-clip-text text-transparent pb-2">
              Algorithmic Trading
            </span>
            <span className="block text-slate-800 mt-2">
              Solutions
            </span>
          </h1>
        </div>

        {/* Subtitle */}
        <p className="text-xl md:text-2xl text-slate-600 mb-12 leading-relaxed max-w-4xl mx-auto font-light">
          Advanced algorithmic trading solutions for modern traders. Specializing in strategy backtesting, 
          trading bots, market scanners, and comprehensive algo trading consultancy.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-16">
          <button 
            onClick={scrollToAbout}
            className="group bg-gradient-to-r from-teal-600 to-blue-600 text-white px-8 py-4 rounded-xl font-semibold transition-all duration-300 hover:scale-105 hover:shadow-2xl flex items-center space-x-3 min-w-[200px]"
          >
            <span>Get Started</span>
            <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
          </button>
          
          <button 
            onClick={scrollToServices}
            className="group bg-white/90 backdrop-blur-sm text-slate-800 px-8 py-4 rounded-xl font-semibold border border-slate-200 transition-all duration-300 hover:bg-slate-50 hover:border-slate-300 hover:shadow-xl flex items-center space-x-3 min-w-[200px]"
          >
            <BarChart3 className="h-5 w-5 group-hover:text-teal-600 transition-colors duration-300" />
            <span>View Services</span>
          </button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200/50 shadow-lg hover:shadow-xl transition-all duration-300">
            <div className="flex items-center justify-center mb-3">
              <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-white" />
              </div>
            </div>
            <div className="text-3xl font-bold text-slate-800 mb-2">
              {liveStats.totalClients}+
            </div>
            <div className="text-slate-600 text-sm font-medium">Happy Clients</div>
          </div>

          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200/50 shadow-lg hover:shadow-xl transition-all duration-300">
            <div className="flex items-center justify-center mb-3">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center">
                <Target className="h-6 w-6 text-white" />
              </div>
            </div>
            <div className="text-3xl font-bold text-slate-800 mb-2">{liveStats.successRate}%</div>
            <div className="text-slate-600 text-sm font-medium">Success Rate</div>
          </div>

          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200/50 shadow-lg hover:shadow-xl transition-all duration-300">
            <div className="flex items-center justify-center mb-3">
              <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl flex items-center justify-center">
                <Zap className="h-6 w-6 text-white" />
              </div>
            </div>
            <div className="text-3xl font-bold text-slate-800 mb-2">{liveStats.activeStrategies}+</div>
            <div className="text-slate-600 text-sm font-medium">Trading Strategies</div>
          </div>

          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 border border-slate-200/50 shadow-lg hover:shadow-xl transition-all duration-300">
            <div className="flex items-center justify-center mb-3">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                <Activity className="h-6 w-6 text-white" />
              </div>
            </div>
            <div className="text-3xl font-bold text-slate-800 mb-2">
              {liveStats.yearsExperience}+
            </div>
            <div className="text-slate-600 text-sm font-medium">Years Experience</div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
        <button 
          onClick={scrollToAbout}
          className="animate-bounce text-slate-400 hover:text-teal-600 transition-colors duration-300"
        >
          <ChevronDown className="h-8 w-8" />
        </button>
      </div>
    </section>
  );
};

export default Hero;