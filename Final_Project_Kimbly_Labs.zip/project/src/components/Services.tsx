import React, { useEffect, useState } from 'react';
import { BarChart3, TrendingUp, Shield, Zap, Bot, Database, Search, BookOpen, Code, Users } from 'lucide-react';

const Services = () => {
  const [skillProgress, setSkillProgress] = useState<{[key: string]: number}>({});

  const services = [
    {
      icon: BarChart3,
      title: 'Strategy Backtesting',
      description: 'Test your trading strategies against historical data to validate performance before risking real capital.',
      features: ['Customized backtesting code', 'Ultra fast backtesting', 'Parameter optimization', 'Detailed analytics & metrics']
    },
    {
      icon: Bot,
      title: 'Trading Bot Creation',
      description: 'Custom-built algorithmic trading bots designed to execute your strategies with precision.',
      features: ['24/7 automated trading', 'Emotion-free execution', 'Equities & Derivatives', 'Commodities trading']
    },
    {
      icon: Search,
      title: 'Market Scanners',
      description: 'Advanced analytical tools to identify market trends, patterns, and potential trading opportunities.',
      features: ['Real-time scanning', 'Pattern recognition', 'Trend analysis', 'Data-driven decisions']
    },
    {
      icon: Users,
      title: 'Consultancy',
      description: 'Comprehensive algo trading consultancy including technology integration and custom strategy creation.',
      features: ['Technology integration', 'Custom strategies', 'Backtesting services', 'Cloud deployment']
    },
    {
      icon: BookOpen,
      title: 'Training',
      description: 'Online & offline expert-led courses on strategy development, backtesting techniques, and programming.',
      features: ['Strategy development', 'Backtesting techniques', 'Programming skills', 'Deployment strategies']
    },
    {
      icon: Code,
      title: 'Custom Indicators',
      description: 'TradingView indicators customized from Pine Script to Python to identify market patterns.',
      features: ['Pine Script to Python', 'Pattern identification', 'Custom indicators', 'Decision-making tools']
    }
  ];

  const tradingMetrics = [
    { name: 'Strategy Backtesting', percentage: 98 },
    { name: 'Bot Development', percentage: 95 },
    { name: 'Market Analysis', percentage: 92 },
    { name: 'Risk Management', percentage: 96 },
    { name: 'Cloud Deployment', percentage: 90 },
    { name: 'Client Satisfaction', percentage: 99 }
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            tradingMetrics.forEach((metric, index) => {
              setTimeout(() => {
                setSkillProgress(prev => ({
                  ...prev,
                  [metric.name]: metric.percentage
                }));
              }, index * 200);
            });
          }
        });
      },
      { threshold: 0.3 }
    );

    const element = document.getElementById('services');
    if (element) observer.observe(element);

    return () => observer.disconnect();
  }, []);

  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Our <span className="text-emerald-600">Services</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive algorithmic trading solutions designed for traders of all levels. 
            From strategy development to deployment, we've got you covered.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div 
                key={index}
                className="group bg-gradient-to-br from-white to-gray-50 rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-gray-100"
              >
                <div className="bg-gradient-to-r from-emerald-600 to-blue-600 w-16 h-16 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Icon className="h-8 w-8 text-white" />
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
                <p className="text-gray-600 mb-6">{service.description}</p>
                
                <ul className="space-y-2">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-sm text-gray-600">
                      <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full mr-3"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        {/* Performance Metrics */}
        <div className="bg-gradient-to-r from-emerald-600 to-blue-600 rounded-2xl p-8 md:p-12 text-white">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl font-bold mb-6">Our Expertise</h3>
              <p className="text-emerald-100 mb-8">
                With over a decade of experience, we have developed business-critical applications 
                for clients in India and abroad, including renowned brands.
              </p>
              <div className="grid grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-2xl font-bold">10+</div>
                  <div className="text-emerald-200 text-sm">Years Experience</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">500+</div>
                  <div className="text-emerald-200 text-sm">Happy Clients</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">99.8%</div>
                  <div className="text-emerald-200 text-sm">Success Rate</div>
                </div>
              </div>
            </div>
            
            <div className="space-y-6">
              {tradingMetrics.map((metric, index) => (
                <div key={index}>
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">{metric.name}</span>
                    <span className="text-emerald-200">{metric.percentage}%</span>
                  </div>
                  <div className="w-full bg-emerald-800/30 rounded-full h-2">
                    <div 
                      className="bg-gradient-to-r from-white to-emerald-200 h-2 rounded-full transition-all duration-1000 ease-out"
                      style={{ width: `${skillProgress[metric.name] || 0}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;