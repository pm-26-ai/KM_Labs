import React from 'react';
import { Award, TrendingUp, Shield, Users, BarChart3, Zap, Code, Database } from 'lucide-react';

const About = () => {
  const achievements = [
    { icon: Award, label: 'Years Experience', count: '10+' },
    { icon: TrendingUp, label: 'Success Rate', count: '95%' },
    { icon: Shield, label: 'Client Satisfaction', count: '99.8%' },
    { icon: Users, label: 'Happy Clients', count: '500+' },
  ];

  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            About <span className="text-emerald-600">Kimbly Labs</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Advanced algorithmic trading solutions for modern traders. Technology-driven company 
            specializing in Algorithmic Trading, Data Science, HRMS, and Hospitality Solutions.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Our Story</h3>
            <div className="space-y-4 text-gray-600">
              <p>
                Kimbly Labs is a technology-driven company specializing in Algorithmic Trading, 
                Data Science, HRMS, and Hospitality Solutions. With over a decade of experience, 
                we have developed business-critical applications for clients in India and abroad, 
                including renowned brands.
              </p>
              <p>
                Founded by seasoned traders and software engineers, we understand the complexities 
                of modern trading and strive to simplify them. Our team combines deep market knowledge 
                with cutting-edge technology to deliver solutions that work.
              </p>
              <p>
                We have successfully served clients across various industries, building robust 
                trading systems, analytical tools, and custom applications that drive business growth 
                and operational efficiency.
              </p>
            </div>
          </div>

          <div className="relative">
            <div className="bg-gradient-to-r from-emerald-600 to-blue-600 rounded-2xl p-8 text-white">
              <h4 className="text-xl font-bold mb-4">Our Mission</h4>
              <p className="mb-6">
                We are on a mission to democratize algorithmic trading, making professional-grade 
                tools accessible to traders of all levels—whether you're a day trader, swing trader, 
                or long-term investor.
              </p>
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                  <BarChart3 className="h-6 w-6" />
                </div>
                <div>
                  <div className="font-semibold">Performance & Reliability</div>
                  <div className="text-white/80 text-sm">Your trusted partner in financial markets</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Achievement Metrics */}
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          {achievements.map((achievement, index) => {
            const Icon = achievement.icon;
            return (
              <div 
                key={index}
                className="bg-white rounded-xl p-6 text-center shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2"
              >
                <div className="bg-gradient-to-r from-emerald-600 to-blue-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon className="h-8 w-8 text-white" />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{achievement.count}</div>
                <div className="text-gray-600 font-medium">{achievement.label}</div>
              </div>
            );
          })}
        </div>

        {/* Expertise Areas */}
        <div className="bg-white rounded-2xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">Our Expertise</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center p-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                <TrendingUp className="h-6 w-6 text-blue-600" />
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">Algorithmic Trading</h4>
              <p className="text-sm text-gray-600">Custom trading bots and automated strategies</p>
            </div>
            
            <div className="text-center p-4">
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                <BarChart3 className="h-6 w-6 text-emerald-600" />
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">Data Science</h4>
              <p className="text-sm text-gray-600">Advanced analytics and machine learning solutions</p>
            </div>
            
            <div className="text-center p-4">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                <Code className="h-6 w-6 text-purple-600" />
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">HRMS Solutions</h4>
              <p className="text-sm text-gray-600">Human resource management systems</p>
            </div>
            
            <div className="text-center p-4">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                <Database className="h-6 w-6 text-orange-600" />
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">Hospitality Solutions</h4>
              <p className="text-sm text-gray-600">Custom applications for hospitality industry</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;