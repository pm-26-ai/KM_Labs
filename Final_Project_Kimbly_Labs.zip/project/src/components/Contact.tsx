import React, { useState } from 'react';
import { Mail, Phone, MapPin, CheckCircle, MessageSquare, Star, Users, TrendingUp } from 'lucide-react';

const Contact = () => {
  const contactInfo = [
    {
      icon: Mail,
      title: 'Email Us',
      detail: 'kimblylabs@gmail.com',
      description: 'Get in touch for trading solutions'
    },
    {
      icon: Phone,
      title: 'Call Us',
      detail: '+91 9873098686',
      description: 'Mon-Fri 9am to 6pm IST'
    },
    {
      icon: MapPin,
      title: 'Visit Us',
      detail: 'Workify Office, 264, Udyog Vihar Phase - 1, Gurugram',
      description: 'Our Development Center'
    }
  ];

  const testimonials = [
    {
      name: 'Sai Krishna Boyina',
      role: 'Head BPA Digital Processes – Operations & Day Trader',
      message: 'Thank you for a wonderful job done. Very clear communication, clarity, and professional service provided... Very prompt in bug fixing too.',
      rating: 5
    },
    {
      name: 'Jason Coleman',
      role: 'Trader, United States',
      message: 'Great Work!',
      rating: 5
    }
  ];

  return (
    <section id="contact" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Contact <span className="text-emerald-600">Us</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Ready to transform your trading with algorithmic solutions? 
            Get in touch with our experts to discuss your requirements.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Left Column - Contact Info & Testimonials */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Get In Touch</h3>
              <p className="text-gray-600 mb-8">
                Our team of experienced developers and traders are ready to help you 
                build the perfect algorithmic trading solution for your needs.
              </p>
            </div>

            {contactInfo.map((info, index) => {
              const Icon = info.icon;
              return (
                <div key={index} className="flex items-start space-x-4">
                  <div className="bg-gradient-to-r from-emerald-600 to-blue-600 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">{info.title}</h4>
                    <p className="text-emerald-600 font-medium mb-1">{info.detail}</p>
                    <p className="text-gray-600 text-sm">{info.description}</p>
                  </div>
                </div>
              );
            })}

            {/* Testimonials */}
            <div className="pt-8 border-t border-gray-200">
              <h4 className="font-semibold text-gray-900 mb-4 flex items-center">
                <MessageSquare className="h-5 w-5 mr-2 text-emerald-600" />
                Client Testimonials
              </h4>
              <div className="space-y-4">
                {testimonials.map((testimonial, index) => (
                  <div key={index} className="bg-white p-4 rounded-lg shadow-sm">
                    <div className="flex items-center mb-2">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                      ))}
                    </div>
                    <p className="text-gray-600 text-sm mb-2">"{testimonial.message}"</p>
                    <div className="text-xs text-gray-500">
                      <div className="font-medium">{testimonial.name}</div>
                      <div>{testimonial.role}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Stats */}
            <div className="bg-gradient-to-r from-emerald-600 to-blue-600 rounded-xl p-6 text-white">
              <h4 className="font-semibold mb-4">Why Choose Us?</h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span>Years of Experience</span>
                  <span className="font-bold">10+</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Happy Clients</span>
                  <span className="font-bold">500+</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Success Rate</span>
                  <span className="font-bold">95%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Enhanced Contact Card with Background Design */}
          <div className="relative">
            {/* Background Design Elements */}
            <div className="absolute -top-4 -right-4 w-24 h-24 bg-gradient-to-br from-emerald-100 to-blue-100 rounded-full opacity-60"></div>
            <div className="absolute top-1/2 -left-6 w-16 h-16 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full opacity-40"></div>
            <div className="absolute -bottom-6 right-1/4 w-20 h-20 bg-gradient-to-br from-emerald-50 to-teal-100 rounded-full opacity-50"></div>
            
            {/* Customer Feedback Icon */}
            <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-12 h-12 bg-gradient-to-r from-emerald-500 to-blue-500 rounded-full flex items-center justify-center shadow-lg">
              <Users className="h-6 w-6 text-white" />
            </div>

            {/* Enhanced Contact Information Card */}
            <div className="relative bg-gradient-to-br from-white via-gray-50 to-white rounded-2xl p-8 shadow-xl border border-gray-100">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Ready to Get Started?</h3>
                <div className="w-16 h-1 bg-gradient-to-r from-emerald-500 to-blue-500 rounded-full mx-auto"></div>
              </div>
              
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-emerald-50 to-emerald-100 border border-emerald-200 rounded-xl p-6 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-20 h-20 bg-emerald-200 rounded-full opacity-20 transform translate-x-8 -translate-y-8"></div>
                  <div className="relative">
                    <div className="flex items-center space-x-3 mb-4">
                      <CheckCircle className="h-6 w-6 text-emerald-500" />
                      <span className="text-emerald-700 font-semibold">Free Consultation Available</span>
                    </div>
                    <p className="text-emerald-600 text-sm">
                      Schedule a free 30-minute consultation to discuss your algorithmic trading requirements and get expert advice.
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center space-x-2 mb-3">
                    <TrendingUp className="h-5 w-5 text-gray-600" />
                    <h4 className="font-semibold text-gray-900">Our Services Include:</h4>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      'Strategy Backtesting',
                      'Trading Bot Creation',
                      'Market Scanners',
                      'Consultancy',
                      'Training',
                      'Custom Indicators'
                    ].map((service, index) => (
                      <div key={index} className="flex items-center text-gray-600 bg-gray-50 rounded-lg px-3 py-2">
                        <div className="w-2 h-2 bg-emerald-600 rounded-full mr-2 flex-shrink-0"></div>
                        <span className="text-sm">{service}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-6 relative overflow-hidden">
                  <div className="absolute bottom-0 left-0 w-16 h-16 bg-blue-200 rounded-full opacity-20 transform -translate-x-4 translate-y-4"></div>
                  <div className="relative">
                    <h4 className="font-semibold text-blue-800 mb-3 flex items-center">
                      <Mail className="h-4 w-4 mr-2" />
                      Contact Methods:
                    </h4>
                    <div className="space-y-2 text-sm text-blue-700">
                      <div className="flex items-center space-x-2">
                        <span>📧</span>
                        <span>kimblylabs@gmail.com</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span>📞</span>
                        <span>+91 9873098686</span>
                      </div>
                      <div className="flex items-start space-x-2">
                        <span>🏢</span>
                        <span>Workify Office, 264, Udyog Vihar Phase - 1, Gurugram</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Trust Indicators */}
                <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-200">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-emerald-600">10+</div>
                    <div className="text-xs text-gray-500">Years</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">500+</div>
                    <div className="text-xs text-gray-500">Clients</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">95%</div>
                    <div className="text-xs text-gray-500">Success</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;