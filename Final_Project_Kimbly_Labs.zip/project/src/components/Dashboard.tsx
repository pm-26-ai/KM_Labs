import React, { useEffect, useState } from 'react';
import { TrendingUp, TrendingDown, DollarSign, Activity, BarChart3, Target, Zap, AlertTriangle } from 'lucide-react';

const Dashboard = () => {
  const [liveData, setLiveData] = useState({
    totalPnL: 0,
    dailyPnL: 0,
    activePositions: 0,
    winRate: 0,
    sharpeRatio: 0,
    maxDrawdown: 0
  });

  const [marketPrices, setMarketPrices] = useState({
    SPY: 485.23,
    QQQ: 412.67,
    GLD: 198.45,
    USO: 78.92,
    BTC: 67420.50,
    VIX: 18.34
  });

  const [chartData, setChartData] = useState<number[]>([]);
  const [positions, setPositions] = useState([
    { symbol: 'AAPL', quantity: 1500, avgPrice: 185.23, currentPrice: 187.45, pnl: 3330, pnlPercent: 1.2 },
    { symbol: 'MSFT', quantity: 800, avgPrice: 412.67, currentPrice: 415.89, pnl: 2576, pnlPercent: 0.78 },
    { symbol: 'GOOGL', quantity: 200, avgPrice: 142.34, currentPrice: 139.87, pnl: -494, pnlPercent: -1.74 },
    { symbol: 'TSLA', quantity: 300, avgPrice: 248.91, currentPrice: 252.15, pnl: 972, pnlPercent: 1.30 },
    { symbol: 'GLD', quantity: 2000, avgPrice: 198.45, currentPrice: 199.23, pnl: 1560, pnlPercent: 0.39 }
  ]);

  const [recentTrades, setRecentTrades] = useState([
    { symbol: 'NVDA', action: 'BUY', quantity: 100, price: 875.23, time: '09:31:45', pnl: 0 },
    { symbol: 'AMD', action: 'SELL', quantity: 500, price: 142.67, time: '09:28:12', pnl: 2340 },
    { symbol: 'SPY', action: 'BUY', quantity: 1000, price: 485.12, time: '09:25:33', pnl: 0 },
    { symbol: 'QQQ', action: 'SELL', quantity: 200, price: 412.89, time: '09:22:18', pnl: 1456 }
  ]);

  useEffect(() => {
    // Animate counters
    const animateCounter = (target: number, key: string) => {
      let current = 0;
      const increment = target / 100;
      const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
          current = target;
          clearInterval(timer);
        }
        setLiveData(prev => ({ ...prev, [key]: Math.floor(current) }));
      }, 20);
    };

    animateCounter(284750, 'totalPnL');
    animateCounter(12340, 'dailyPnL');
    animateCounter(47, 'activePositions');
    animateCounter(87, 'winRate');
    animateCounter(234, 'sharpeRatio'); // Will be divided by 100 for display
    animateCounter(982, 'maxDrawdown'); // Will be divided by 100 for display

    // Generate chart data
    const data = Array.from({ length: 24 }, (_, i) => {
      const baseValue = 50;
      const trend = i * 2;
      const noise = (Math.random() - 0.5) * 10;
      return Math.max(10, Math.min(90, baseValue + trend + noise));
    });
    setChartData(data);

    // Update market prices every 3 seconds
    const priceInterval = setInterval(() => {
      setMarketPrices(prev => ({
        SPY: prev.SPY + (Math.random() - 0.5) * 2,
        QQQ: prev.QQQ + (Math.random() - 0.5) * 3,
        GLD: prev.GLD + (Math.random() - 0.5) * 1,
        USO: prev.USO + (Math.random() - 0.5) * 1.5,
        BTC: prev.BTC + (Math.random() - 0.5) * 500,
        VIX: Math.max(10, prev.VIX + (Math.random() - 0.5) * 1)
      }));

      // Update positions
      setPositions(prev => prev.map(pos => {
        const change = (Math.random() - 0.5) * 2;
        const newPrice = pos.currentPrice + change;
        const newPnl = (newPrice - pos.avgPrice) * pos.quantity;
        const newPnlPercent = ((newPrice - pos.avgPrice) / pos.avgPrice) * 100;
        
        return {
          ...pos,
          currentPrice: newPrice,
          pnl: newPnl,
          pnlPercent: newPnlPercent
        };
      }));
    }, 3000);

    return () => clearInterval(priceInterval);
  }, []);

  const dashboardCards = [
    {
      title: 'Total P&L',
      value: `$${liveData.totalPnL.toLocaleString()}`,
      icon: DollarSign,
      change: '+12.5%',
      changeType: 'positive',
      color: 'from-emerald-500 to-green-600'
    },
    {
      title: 'Daily P&L',
      value: `$${liveData.dailyPnL.toLocaleString()}`,
      icon: TrendingUp,
      change: '+8.2%',
      changeType: 'positive',
      color: 'from-blue-500 to-cyan-600'
    },
    {
      title: 'Active Positions',
      value: liveData.activePositions.toString(),
      icon: Target,
      change: '+3',
      changeType: 'positive',
      color: 'from-purple-500 to-pink-600'
    },
    {
      title: 'Win Rate',
      value: `${liveData.winRate}%`,
      icon: Activity,
      change: '+2.1%',
      changeType: 'positive',
      color: 'from-orange-500 to-red-600'
    }
  ];

  return (
    <section id="dashboard" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Live Trading <span className="text-emerald-600">Dashboard</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Real-time portfolio performance, active positions, and market data 
            with live P&L tracking and risk metrics.
          </p>
          <div className="flex items-center justify-center mt-4">
            <div className="flex items-center space-x-2 px-4 py-2 bg-emerald-50 rounded-full">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
              <span className="text-emerald-700 text-sm font-medium">Live Data Feed</span>
            </div>
          </div>
        </div>

        {/* Main Stats Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {dashboardCards.map((card, index) => {
            const Icon = card.icon;
            return (
              <div 
                key={index}
                className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${card.color} flex items-center justify-center`}>
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                    card.changeType === 'positive' ? 'bg-emerald-100 text-emerald-600' : 'bg-red-100 text-red-600'
                  }`}>
                    {card.change}
                  </div>
                </div>
                <div className="text-2xl font-bold text-gray-900 mb-1">{card.value}</div>
                <div className="text-gray-600 text-sm">{card.title}</div>
              </div>
            );
          })}
        </div>

        <div className="grid lg:grid-cols-3 gap-8 mb-8">
          {/* Performance Chart */}
          <div className="lg:col-span-2 bg-white rounded-xl p-6 shadow-lg border border-gray-100">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900">Portfolio Performance</h3>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Activity className="h-4 w-4" />
                <span>Last 24 Hours</span>
              </div>
            </div>
            
            <div className="h-64 flex items-end space-x-1">
              {chartData.map((value, index) => (
                <div 
                  key={index}
                  className="flex-1 bg-gradient-to-t from-emerald-600 to-blue-500 rounded-t-sm transition-all duration-1000 ease-out"
                  style={{ 
                    height: `${value}%`,
                    animationDelay: `${index * 50}ms`
                  }}
                ></div>
              ))}
            </div>
            
            <div className="flex justify-between mt-2 text-xs text-gray-500">
              {Array.from({length: 6}, (_, i) => (
                <span key={i}>{String(i * 4).padStart(2, '0')}:00</span>
              ))}
            </div>
          </div>

          {/* Market Prices */}
          <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Live Market Prices</h3>
            <div className="space-y-4">
              {Object.entries(marketPrices).map(([symbol, price]) => {
                const change = (Math.random() - 0.5) * 2;
                const isPositive = change > 0;
                return (
                  <div key={symbol} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                        <span className="text-xs font-bold text-gray-600">{symbol}</span>
                      </div>
                      <span className="font-medium text-gray-900">{symbol}</span>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-gray-900">
                        ${typeof price === 'number' ? price.toFixed(2) : price}
                      </div>
                      <div className={`text-xs flex items-center ${
                        isPositive ? 'text-emerald-600' : 'text-red-600'
                      }`}>
                        {isPositive ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
                        {Math.abs(change).toFixed(2)}%
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Positions and Recent Trades */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Active Positions */}
          <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Active Positions</h3>
            <div className="space-y-4">
              {positions.map((position, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <div className="font-bold text-gray-900">{position.symbol}</div>
                    <div className="text-sm text-gray-600">{position.quantity} shares @ ${position.avgPrice.toFixed(2)}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-gray-900">${position.currentPrice.toFixed(2)}</div>
                    <div className={`text-sm flex items-center ${
                      position.pnl >= 0 ? 'text-emerald-600' : 'text-red-600'
                    }`}>
                      {position.pnl >= 0 ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
                      ${Math.abs(position.pnl).toFixed(0)} ({position.pnlPercent.toFixed(2)}%)
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Trades */}
          <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Recent Trades</h3>
            <div className="space-y-4">
              {recentTrades.map((trade, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                      trade.action === 'BUY' ? 'bg-emerald-100 text-emerald-600' : 'bg-red-100 text-red-600'
                    }`}>
                      {trade.action === 'BUY' ? 'B' : 'S'}
                    </div>
                    <div>
                      <div className="font-bold text-gray-900">{trade.symbol}</div>
                      <div className="text-sm text-gray-600">{trade.quantity} @ ${trade.price.toFixed(2)}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-gray-600">{trade.time}</div>
                    {trade.pnl > 0 && (
                      <div className="text-sm text-emerald-600 font-medium">+${trade.pnl}</div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Risk Metrics */}
        <div className="mt-8 grid md:grid-cols-4 gap-6">
          <div className="bg-gradient-to-r from-emerald-600 to-blue-600 rounded-xl p-6 text-white">
            <h4 className="text-lg font-semibold mb-4">Sharpe Ratio</h4>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{(liveData.sharpeRatio / 100).toFixed(2)}</div>
              <div className="w-16 h-16 rounded-full border-4 border-white/30 flex items-center justify-center">
                <BarChart3 className="h-8 w-8" />
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl p-6 text-white">
            <h4 className="text-lg font-semibold mb-4">Max Drawdown</h4>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">-{(liveData.maxDrawdown / 100).toFixed(1)}%</div>
              <div className="w-16 h-16 rounded-full border-4 border-white/30 flex items-center justify-center">
                <AlertTriangle className="h-8 w-8" />
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-orange-600 to-red-600 rounded-xl p-6 text-white">
            <h4 className="text-lg font-semibold mb-4">Portfolio Beta</h4>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">0.85</div>
              <div className="w-16 h-16 rounded-full border-4 border-white/30 flex items-center justify-center">
                <Zap className="h-8 w-8" />
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-blue-600 to-teal-600 rounded-xl p-6 text-white">
            <h4 className="text-lg font-semibold mb-4">Volatility</h4>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">14.2%</div>
              <div className="w-16 h-16 rounded-full border-4 border-white/30 flex items-center justify-center">
                <Activity className="h-8 w-8" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Dashboard;