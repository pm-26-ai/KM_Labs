import React, { useState } from 'react';
import { TrendingUp, Shield, Zap, Activity, Target, BarChart3, Smartphone, Cloud } from 'lucide-react';

const Portfolio = () => {
  const [activeFilter, setActiveFilter] = useState('all');

  const features = [
    {
      id: 1,
      title: 'High Accuracy',
      category: 'performance',
      description: 'Advanced algorithms designed for precision trading in any market condition.',
      icon: Target,
      highlight: 'Advanced Algorithms',
      image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=800',
      benefits: ['Precision trading', 'Market adaptability', 'Consistent performance', 'Risk optimization']
    },
    {
      id: 2,
      title: 'Multi-Platform Integration',
      category: 'integration',
      description: 'Seamless integration with major exchanges and trading platforms worldwide.',
      icon: BarChart3,
      highlight: 'Universal Compatibility',
      image: 'https://images.pexels.com/photos/730547/pexels-photo-730547.jpeg?auto=compress&cs=tinysrgb&w=800',
      benefits: ['Major exchanges', 'Multiple platforms', 'Easy integration', 'Global reach']
    },
    {
      id: 3,
      title: 'Real-Time Execution',
      category: 'performance',
      description: 'Low-latency execution system to seize fleeting market opportunities instantly.',
      icon: Zap,
      highlight: 'Lightning Fast',
      image: 'https://images.pexels.com/photos/186461/pexels-photo-186461.jpeg?auto=compress&cs=tinysrgb&w=800',
      benefits: ['Low latency', 'Instant execution', 'Market opportunities', 'Speed advantage']
    },
    {
      id: 4,
      title: 'Web Based UI',
      category: 'interface',
      description: 'Fast and interactive bot management through intuitive web-based interface.',
      icon: Activity,
      highlight: 'User Friendly',
      image: 'https://images.pexels.com/photos/159888/pexels-photo-159888.jpeg?auto=compress&cs=tinysrgb&w=800',
      benefits: ['Interactive UI', 'Easy management', 'Real-time monitoring', 'Intuitive design']
    },
    {
      id: 5,
      title: 'Bank-Level Security',
      category: 'security',
      description: 'Enterprise-grade encryption ensuring complete protection of your data and assets.',
      icon: Shield,
      highlight: 'Maximum Security',
      image: 'https://images.pexels.com/photos/210607/pexels-photo-210607.jpeg?auto=compress&cs=tinysrgb&w=800',
      benefits: ['Bank-level encryption', 'Data protection', 'Asset security', 'Privacy assured']
    },
    {
      id: 6,
      title: 'Advanced Analytics',
      category: 'analytics',
      description: 'Comprehensive visualizations and performance metrics for informed decision making.',
      icon: TrendingUp,
      highlight: 'Data Insights',
      image: 'https://images.pexels.com/photos/844124/pexels-photo-844124.jpeg?auto=compress&cs=tinysrgb&w=800',
      benefits: ['Visual analytics', 'Performance metrics', 'Data insights', 'Smart decisions']
    },
    {
      id: 7,
      title: 'Cloud Deployment',
      category: 'infrastructure',
      description: 'VPS-based execution ensuring 24/7 uptime and reliable trading operations.',
      icon: Cloud,
      highlight: '24/7 Uptime',
      image: 'https://images.pexels.com/photos/325229/pexels-photo-325229.jpeg?auto=compress&cs=tinysrgb&w=800',
      benefits: ['VPS deployment', '24/7 operation', 'High reliability', 'Cloud infrastructure']
    },
    {
      id: 8,
      title: 'Mobile Notifications',
      category: 'alerts',
      description: 'Real-time alerts and notifications via Telegram and Pushover for instant updates.',
      icon: Smartphone,
      highlight: 'Instant Alerts',
      image: 'https://images.pexels.com/photos/607812/pexels-photo-607812.jpeg?auto=compress&cs=tinysrgb&w=800',
      benefits: ['Telegram alerts', 'Pushover notifications', 'Real-time updates', 'Mobile friendly']
    }
  ];

  const filters = [
    { id: 'all', label: 'All Features' },
    { id: 'performance', label: 'Performance' },
    { id: 'security', label: 'Security' },
    { id: 'integration', label: 'Integration' },
    { id: 'analytics', label: 'Analytics' }
  ];

  const filteredFeatures = activeFilter === 'all' 
    ? features 
    : features.filter(feature => feature.category === activeFilter);

  return (
    <section id="portfolio" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Key <span className="text-emerald-600">Features</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Discover the powerful features that make Kimbly Labs the preferred choice 
            for algorithmic trading solutions across the globe.
          </p>

          {/* Filter Buttons */}
          <div className="flex flex-wrap justify-center gap-4">
            {filters.map((filter) => (
              <button
                key={filter.id}
                onClick={() => setActiveFilter(filter.id)}
                className={`px-6 py-3 rounded-lg font-medium transition-all duration-300 ${
                  activeFilter === filter.id
                    ? 'bg-emerald-600 text-white shadow-lg'
                    : 'bg-white text-gray-600 hover:bg-emerald-50 hover:text-emerald-600'
                }`}
              >
                {filter.label}
              </button>
            ))}
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredFeatures.map((feature) => {
            const Icon = feature.icon;
            return (
              <div 
                key={feature.id}
                className="group bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2"
              >
                <div className="relative overflow-hidden">
                  <img 
                    src={feature.image} 
                    alt={feature.title}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4">
                    <span className="px-3 py-1 rounded-full text-xs font-medium bg-emerald-100 text-emerald-700">
                      {feature.highlight}
                    </span>
                  </div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <div className="flex items-center space-x-2">
                      <Icon className="h-6 w-6 text-white" />
                      <span className="font-bold text-lg text-white">
                        {feature.title}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="p-6">
                  <p className="text-gray-600 mb-4">{feature.description}</p>
                  
                  {/* Benefits */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {feature.benefits.map((benefit, index) => (
                      <span 
                        key={index}
                        className="px-2 py-1 bg-emerald-50 text-emerald-600 text-xs rounded-full"
                      >
                        {benefit}
                      </span>
                    ))}
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-emerald-600 font-medium">
                      <Activity className="h-4 w-4 mr-2" />
                      <span>Learn More</span>
                    </div>
                    <Icon className="h-5 w-5 text-gray-400" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Feature Summary */}
        <div className="mt-16 bg-gradient-to-r from-emerald-600 to-blue-600 rounded-2xl p-8 md:p-12 text-white">
          <div className="text-center mb-8">
            <h3 className="text-2xl md:text-3xl font-bold mb-4">
              Why Choose Kimbly Labs?
            </h3>
            <p className="text-emerald-100 max-w-2xl mx-auto">
              With a strong focus on performance, reliability, and user experience, 
              Kimbly Labs is your trusted partner in navigating today's fast-paced financial markets.
            </p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold mb-2">99.9%</div>
              <div className="text-emerald-200">Uptime Guarantee</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold mb-2">24/7</div>
              <div className="text-emerald-200">Support Available</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold mb-2">500+</div>
              <div className="text-emerald-200">Satisfied Clients</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold mb-2">10+</div>
              <div className="text-emerald-200">Years Experience</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;